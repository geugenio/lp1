#include "Item.h"

void Item::descricao() const{
    cout << "ID " << id << " | Nome: " << nome << " | Valor: R$" << valor <<endl;
}
